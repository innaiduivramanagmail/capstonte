const Data = [
    {
        id: 1,
        title: "cream-humjoli",
        price: 2500,
        content: "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Soluta repellendus hic facilis voluptates esse doloribus dolorum! Quae voluptatem odio nobis non libero cumque nisi, blanditiis, impedit, animi quisquam necessitatibus autem.",
        img: "https://rukminim1.flixcart.com/image/832/832/xif0q/blazer/q/7/f/42-cream-humjoli-mens-wear-original-imaghxktbz2chvhe.jpeg?q=70"
    },
    {
        id: 2,
        title: "mens-coat",
      price: 2000,
        content: "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Soluta repellendus hic facilis voluptates esse doloribus dolorum! Quae voluptatem odio nobis non libero cumque nisi, blanditiis, impedit, animi quisquam necessitatibus autem.",
        img: "https://4.imimg.com/data4/SP/JF/MY-25044844/mens-coat-2-500x500.jpg"
    },
    {
        id: 3,
        title: "pre-wedding-outfit",
      price: 3000,
        content: "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Soluta repellendus hic facilis voluptates esse doloribus dolorum! Quae voluptatem odio nobis non libero cumque nisi, blanditiis, impedit, animi quisquam necessitatibus autem.",
        img: "https://shaadiwish.com/blog/wp-content/uploads/2022/01/pre-wedding-outfit-1.jpg"
    },
    {
        id: 4,
        title: "premium-maroon-silayi-humjoli",
      price: 2750,
        content: "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Soluta repellendus hic facilis voluptates esse doloribus dolorum! Quae voluptatem odio nobis non libero cumque nisi, blanditiis, impedit, animi quisquam necessitatibus autem.",
        img: "https://rukminim1.flixcart.com/image/832/832/xif0q/blazer/t/l/a/38-premium-maroon-silayi-humjoli-mens-wear-original-imagg56cc96xex7z.jpeg?q=70"
    },
    {
        id: 5,
        title: "Encrypted Watch",
      price: 700,
        content: "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Soluta repellendus hic facilis voluptates esse doloribus dolorum! Quae voluptatem odio nobis non libero cumque nisi, blanditiis, impedit, animi quisquam necessitatibus autem.",
        img: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTZbXuc5Eb3wjWrp0BrKo19hho_dxh0sVA6tV5b_tbhlvv6gUxipJOKqMpyAgpYxqdiZVs&usqp=CAU"
    },
    {
        id: 6,
        title:  "silver Watch",
        price: 500,
        content: "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Soluta repellendus hic facilis voluptates esse doloribus dolorum! Quae voluptatem odio nobis non libero cumque nisi, blanditiis, impedit, animi quisquam necessitatibus autem.",
        img: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQe25_UDmK4XG_LVDrJIyRKrhRkEHl_Q45TFw&usqp=CAU"
    },
    {
        id: 7,
        title: "Watch Combo set",
        price: 1500,
        content: "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Soluta repellendus hic facilis voluptates esse doloribus dolorum! Quae voluptatem odio nobis non libero cumque nisi, blanditiis, impedit, animi quisquam necessitatibus autem.",
        img: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQX6iuKIbMNvGY8hZJNTzQomLk-rQ1b5RzNZw&usqp=CAU"
    },
    {
        id: 8,
        title: "Lether Watch",
        price: 350,
        content: "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Soluta repellendus hic facilis voluptates esse doloribus dolorum! Quae voluptatem odio nobis non libero cumque nisi, blanditiis, impedit, animi quisquam necessitatibus autem.",
        img: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT_96-_Fvk6ikON6Rb9Qj6hs8aToYopXDlgxA&usqp=CAU"
    },
    {
        id: 9,
        title: "leather Bracelet",
        price: 230,
        content: "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Soluta repellendus hic facilis voluptates esse doloribus dolorum! Quae voluptatem odio nobis non libero cumque nisi, blanditiis, impedit, animi quisquam necessitatibus autem.",
        img: "https://assets.ajio.com/medias/sys_master/root/20220721/NbYh/62d98101aeb26921af8cfca3/shining_diva_brown_9905b_pack_of_5_multi-strand_leather_bracelets.jpg"
    },
    {
        id: 10,
        title: "Silver Bracelet",
        price: 200,
        content: "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Soluta repellendus hic facilis voluptates esse doloribus dolorum! Quae voluptatem odio nobis non libero cumque nisi, blanditiis, impedit, animi quisquam necessitatibus autem.",
        img: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSlagKUUy65LLN9BK5n0IJkdXufd_pwiHossg&usqp=CAU"
    },
    {
        id: 11,
        title:"Stylish Brace",
        price: 340,
        content: "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Soluta repellendus hic facilis voluptates esse doloribus dolorum! Quae voluptatem odio nobis non libero cumque nisi, blanditiis, impedit, animi quisquam necessitatibus autem.",
        img: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQOF4ipI7Ldx0LGB-Wfz55aMUac5NJKJ3aqQw&usqp=CAU"
    },
    {
        id: 12,
        title: "Pearls Stylish Bracelet",
        price: 120,
        content: "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Soluta repellendus hic facilis voluptates esse doloribus dolorum! Quae voluptatem odio nobis non libero cumque nisi, blanditiis, impedit, animi quisquam necessitatibus autem.",
        img: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS1hR5xvAecE4_nfos5-gSxPh3VOcrRTsLYDg&usqp=CAU"
    },
    {
        id: 13,
        title: "Pants Combo set",
        price: 2400,
        content: "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Soluta repellendus hic facilis voluptates esse doloribus dolorum! Quae voluptatem odio nobis non libero cumque nisi, blanditiis, impedit, animi quisquam necessitatibus autem.",
        img: "https://m.media-amazon.com/images/W/IMAGERENDERING_521856-T1/images/I/71av-5slb-L._SX679._SX._UX._SY._UY_.jpg"
    },
    {
        id: 14,
        title: "Black Pant",
        price: 350,
        content: "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Soluta repellendus hic facilis voluptates esse doloribus dolorum! Quae voluptatem odio nobis non libero cumque nisi, blanditiis, impedit, animi quisquam necessitatibus autem.",
        img: "https://assets.ajio.com/medias/sys_master/root/20211005/f0re/615bd9c8aeb2692b85a9d252/-473Wx593H-463079399-navy-MODEL.jpg"
    },
    {
        id: 15,
        title:  "Boot cut pant",
        price: 1500,
        content: "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Soluta repellendus hic facilis voluptates esse doloribus dolorum! Quae voluptatem odio nobis non libero cumque nisi, blanditiis, impedit, animi quisquam necessitatibus autem.",
        img: "https://5.imimg.com/data5/SELLER/Default/2022/7/IG/WN/HH/113537806/cargo-pant-500x500.jpg"
    },
    {
        id: 16,
        title:  "Black shoe",
        price: 500,
        content: "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Soluta repellendus hic facilis voluptates esse doloribus dolorum! Quae voluptatem odio nobis non libero cumque nisi, blanditiis, impedit, animi quisquam necessitatibus autem.",
        img: "https://5.imimg.com/data5/CI/DI/GY/SELLER-32493408/00-500x500.jpg"
    },
    {
        id: 17,
        title: "White shoe",
        price: 550,
        content: "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Soluta repellendus hic facilis voluptates esse doloribus dolorum! Quae voluptatem odio nobis non libero cumque nisi, blanditiis, impedit, animi quisquam necessitatibus autem.",
        img: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRPxfYfU0IcHGLudw8Eh9rYjHSXTXGFUXB6nzpuPIaUF1IABs8xMA95eLWsReCcTAau_L0&usqp=CAU"
    },
    {
        id: 18,
        title: "mens sandels",
        price: 350,
        content: "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Soluta repellendus hic facilis voluptates esse doloribus dolorum! Quae voluptatem odio nobis non libero cumque nisi, blanditiis, impedit, animi quisquam necessitatibus autem.",
        img: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRbBUlr4u4gjkHlPNzVkkGL90h_-hd6kiNUAw&usqp=CAU"
    },
    {
        id: 19,
        title: "Cream stylish shoe",
        price: 430,
        content: "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Soluta repellendus hic facilis voluptates esse doloribus dolorum! Quae voluptatem odio nobis non libero cumque nisi, blanditiis, impedit, animi quisquam necessitatibus autem.",
        img: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTXAjUFO-gKxeWTI2mwavmXyQbojGHgFoB_rQ&usqp=CAU"
    },
    {
        id: 20,
        title: "Flexible shoe",
        price: 450,
        content: "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Soluta repellendus hic facilis voluptates esse doloribus dolorum! Quae voluptatem odio nobis non libero cumque nisi, blanditiis, impedit, animi quisquam necessitatibus autem.",
        img: "https://rukminim1.flixcart.com/image/832/832/xif0q/shoe/m/m/v/-original-imagg7szgcmfgauh.jpeg?q=70"
    },
    {
        id: 21,
        title: "Black sun glasses",
        price: 150,
        content: "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Soluta repellendus hic facilis voluptates esse doloribus dolorum! Quae voluptatem odio nobis non libero cumque nisi, blanditiis, impedit, animi quisquam necessitatibus autem.",
        img: "https://m.media-amazon.com/images/W/IMAGERENDERING_521856-T1/images/I/31-i5AaCDxL.jpg"
    },
    {
        id: 22,
        title: "Mens glass stylish",
        price: 170,
        content: "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Soluta repellendus hic facilis voluptates esse doloribus dolorum! Quae voluptatem odio nobis non libero cumque nisi, blanditiis, impedit, animi quisquam necessitatibus autem.",
        img: "https://5.imimg.com/data5/ANDROID/Default/2021/3/KM/SN/GR/16516658/product-jpeg-500x500.jpg"
    },
    {
        id: 23,
        title: "Sun glasses",
        price: 230,
        content: "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Soluta repellendus hic facilis voluptates esse doloribus dolorum! Quae voluptatem odio nobis non libero cumque nisi, blanditiis, impedit, animi quisquam necessitatibus autem.",
        img: "https://5.imimg.com/data5/LM/NU/MY-36086933/men-sunglasses-500x500.jpg"
    },
    {
        id: 24,
        title: "Stylish glasses",
        price: 410,
        content: "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Soluta repellendus hic facilis voluptates esse doloribus dolorum! Quae voluptatem odio nobis non libero cumque nisi, blanditiis, impedit, animi quisquam necessitatibus autem.",
        img: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTC2AO9ZHjoyXjXpc6ZaGwLTkUNwlUuoNH2zA&usqp=CAU"
    },
    {
        id: 25,
        title: "Optical frames",
        price: 120,
        content: "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Soluta repellendus hic facilis voluptates esse doloribus dolorum! Quae voluptatem odio nobis non libero cumque nisi, blanditiis, impedit, animi quisquam necessitatibus autem.",
        img: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcToImzJ1GGUqroQCoKaHr19EB7oYDusqadzca03YA6fjjY75jMrspSHou2_JBjLB7hm_TE&usqp=CAU"
    },
    {
        id: 26,
        title:  "Silver Diamond Ring",
        price: 5400,
        content: "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Soluta repellendus hic facilis voluptates esse doloribus dolorum! Quae voluptatem odio nobis non libero cumque nisi, blanditiis, impedit, animi quisquam necessitatibus autem.",
        img: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQBJZCWCB5IpnOltqXPxIkQ4QnjMzrO-HmqZA&usqp=CAU"
    },
    {
        id: 27,
        title: "Silver coated ring",
        price: 5000,
        content: "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Soluta repellendus hic facilis voluptates esse doloribus dolorum! Quae voluptatem odio nobis non libero cumque nisi, blanditiis, impedit, animi quisquam necessitatibus autem.",
        img: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT3ryGxyiMfWTsR5LBR6WQUidNSB3OE2xP81w&usqp=CAU"
    },
    {
        id: 28,
        title: "Gold ring stylish",
        price: 7000,
        content: "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Soluta repellendus hic facilis voluptates esse doloribus dolorum! Quae voluptatem odio nobis non libero cumque nisi, blanditiis, impedit, animi quisquam necessitatibus autem.",
        img: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTow3i9pSmzmIju6J7r5oZx11pgUdptHaTX5A&usqp=CAU"
    },
    {
        id: 29,
        title: "mens stylish rings",
        price: 530,
        content: "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Soluta repellendus hic facilis voluptates esse doloribus dolorum! Quae voluptatem odio nobis non libero cumque nisi, blanditiis, impedit, animi quisquam necessitatibus autem.",
        img: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ9Gd0c3cCyrfphjJw_Yl13-mJhntLLhnHMrA&usqp=CAU"
    },
    {
        id: 30,
        title: "Gold stylish ",
        price: 5000,
        content: "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Soluta repellendus hic facilis voluptates esse doloribus dolorum! Quae voluptatem odio nobis non libero cumque nisi, blanditiis, impedit, animi quisquam necessitatibus autem.",
        img: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ9YeUH2pl5SErQDlV2r5a0fzMw9Q3Uv49RiA&usqp=CAU"
    }
]

export default Data;