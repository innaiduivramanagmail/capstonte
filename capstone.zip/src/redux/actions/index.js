export const AddItem=(product)=>{
return {
    type:"ADDITEM",
    payload:product
}
}

export const DelItem=(product)=>{
    return {
        type:"DELITEM",
        payload:product
    }
    }