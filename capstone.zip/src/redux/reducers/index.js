import addItem from "./Additem";
import {combineReducers} from  'redux'

const rootReducers=combineReducers({
    addItem
})

export default rootReducers;