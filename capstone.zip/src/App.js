import React from 'react'
import Header from './components/Header'
import Footer from './components/Footer'
import Home from './components/Home'
import Product from './components/Product'
import Contact from './components/Contact'
import About from './components/About'
import { BrowserRouter, Route, Routes } from 'react-router-dom'
import ProductDetail from './components/ProductDetail'
//import Cart from './components/buttons/Cart'
import store from './redux/Store';
import { Provider } from 'react-redux';
import CartPage from './components/CartPage'
import SignUp from './components/buttons/SignUp'
import Login from './components/buttons/Login'
import Profile from './components/buttons/Profile'
import './App'
import { useState } from 'react'
import { ToastContainer } from 'react-toastify'
import { AuthProvider } from './components/Auth'
import AddProduct from './components/AddProduct'
import EditProduct from './components/EditProduct'
import Charts from './components/Charts'

//import Warning from "./Warning";
//import { Auth1Provider } from './components/Auth1'


function App() {

  const [cart, setCart] = useState([])

  const handleClick = (item) => {
    let isPresent = false;
    cart.forEach((product) => {
      if (item.id === product.id) {
        isPresent = true
      }
    })
    if (isPresent)
      return;
    setCart([...cart, item]);

    //console.log(item)
  }
  return (
    <div className='App'>
      <AuthProvider>
      
      <ToastContainer theme='colored'></ToastContainer>
      <BrowserRouter>
        <Provider store={store}>
          <Header size={cart.length} handleClick={handleClick}></Header>

          <Routes>
            <Route path="/" exact Component={Home} />
            <Route path="/products" exact element={<Product handleClick={handleClick} />} />
            <Route path="/products/:id" exact Component={ProductDetail} />
            <Route path="/about" exact Component={About} />
            <Route path="/contact" exact Component={Contact} />
            <Route path="/chart" exact Component={Charts} />
            <Route path="/addproduct" exact Component={AddProduct} />
            <Route path="/edit" exact Component={EditProduct} />
            <Route path="/cart" exact Component={CartPage} />
            <Route path="/register" exact Component={SignUp} />
            <Route path="/profile" exact Component={Profile} />
            <Route path="/login" exact Component={Login} />
            <Route path="/login" exact Component={Login} />

          </Routes>
          <Footer></Footer>
        </Provider>
      </BrowserRouter>
     
      </AuthProvider>
    </div>
  )
}

export default App
