import axios from "axios";

export const fetchData = () => {
  return (dispatch) => {
    axios
      .get("http://localhost:3000/products")
      .then((value) => {
        dispatch({ type: "getData", payload: value.data });
      })
      .catch((err) => {
        console.log("Error:" + err);
      });
  };
};

export const addData = (data) => {
  return (dispatch) => {
    dispatch({ type: "addData", payload: data });
  };
};
