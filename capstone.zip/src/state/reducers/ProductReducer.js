import axios from "axios";

const Dbreducer=(state=[{}],action)=>{
    switch(action.type){
        case 'getData':
            console.log(action.payload)
            return action.payload
        case 'addData':
            axios.post('http://localhost:3001/products',action.payload)
            .then(console.log('success'))
            .catch(err=>{console.log(err)})
            return[...state,action.payload]
        default:
            return state
    }
}
export default Dbreducer;