import React from "react";
//import axios from "axios";
import { Formik, Form, Field, ErrorMessage } from "formik";
import * as yup from "yup";
import { useNavigate } from "react-router-dom";
import { useDispatch } from "react-redux";
import * as actions from "./action-creator/actions";
const AddProduct = () => {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const validationSchema = yup.object({
    name: yup
      .string()
      .min(3, "Name must be at least 3 characters in length!")
      .max(20, "Maximum length of name can not be more then 20 characters!")
      .required(<p style={{ color: "red" }}>Product Name is required</p>),
    quantity: yup
      .number()
      .min(1, "Quantity can not be less then 1")
      .max(10, "Quantity can not be more then 10!")
      .required(<p style={{ color: "red" }}>Quantity is required!</p>),
    price: yup
      .number()
      .min(10, "Price can not be less then 10")
      .max(100000, "Price can not be more then 10000!")
      .required(<p style={{ color: "red" }}>Price is required!</p>),
  });
  const submit = (e, { resetForm }) => {
    resetForm({ values: "" });
    //console.log(cb);
    dispatch(actions.addData(e));
    navigate("/products");
  };

  return (
    <div>
      <h1>Add Product</h1>
      <Formik
        initialValues={{ name: "", quantity: "", price: "" }}
        validationSchema={validationSchema}
        onSubmit={submit}
      >
        <Form>
          <div className="form">
            <Field name="name" type="text" placeholder="Product Name" />
            <ErrorMessage name="name" />
            <br /> <br />
            <Field name="quantity" type="number" placeholder="Quantity" />
            <ErrorMessage name="quantity" />
            <br /> <br />
            <Field name="price" type="number" placeholder="Price" />
            <ErrorMessage name="price" />
            <br /> <br />
            <button type="submit">Submit</button>
          </div>
        </Form>
      </Formik>
    </div>
  );
};

export default AddProduct;
