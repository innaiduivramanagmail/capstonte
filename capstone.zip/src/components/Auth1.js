import {  createContext, useContext, useState } from 'react'

const Auth1Context=createContext(null)

export const Auth1Provider=({children})=>{
    const[email,setLogin]=useState(null);

   
    const login=(email)=>{
        setLogin(email)
    }
return <Auth1Context.Provider value={{email,login}}>{children}</Auth1Context.Provider>
}
 export const useAuth1=()=>{
    return useContext(Auth1Context)
 }