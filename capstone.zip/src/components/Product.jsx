import React from 'react'
import { Link } from 'react-router-dom'
//import Data from '../Data.jsx'
import { useContext, useState, useEffect } from 'react'
import { Cartcontext } from '../context/Context.js'
import { useAuth } from './Auth.js'
import { toast } from 'react-toastify'
import { validateYupSchema } from 'formik'
//import { useAuth1 } from './Auth1.js'

function Product() {


  const [search, setSearch] = useState('')
  const auth = useAuth()
  //  const auth1 = useAuth1()
  const Globalstate = useContext(Cartcontext);
  const dispatch = Globalstate.dispatch;


  const [products, setProducts] = useState([])
  const[delmesg,setDelMsg]=useState('')
  useEffect(() => {
    fetch('http://localhost:3000/products')
      .then(response => response.json())
      .then(json => setProducts(json))
  }, [])

  const handlealert = () => {
    if (window.confirm("Are you sure you want see product details?")) {
    }
    else {
      window.location = '/products'
    }
  }
  const handlecart = () => {
    if (window.confirm("Are you sure you want to add to cart?")) {
    }
    else {
      window.location = '/products'
    }
  }
  const handledelete = () => {


    const checkedInputValue=[];
    for(let i=0;i<products.length;i++){
      if(products[i].isChecked===true){
        checkedInputValue.push(parseInt(products[i].id))
      }
    }

    
    if (window.confirm("Are you sure you want delete products?")) {
    }
    else {
      window.location = '/products'
    }

    
   console.log(JSON.stringify(checkedInputValue))
  }

  const [isChecked, setIsChecked] = useState([])
  const handleCheckBox = (e) => {
    const { name, checked } = e.target;
    // console.log(value)
    if (name === "allselect") {
      const checkedValue = products.map((product) => { return { ...product, isChecked: checked } })
      console.log(checkedValue)
      setProducts(checkedValue)
    }else{
      const checkedValue=products.map((product)=>
      product.title===name? {...product,isChecked:checked}:product)
      console.log(checkedValue)
      setProducts(checkedValue)
    }
  }

  const cardItem = (item) => {
    item.quantity = 1;
    return (
      <>
        <div class="card my-5 py-4 bg-warning" key={item.id} style={{ width: "18rem" }}>
          <span><input type='checkbox' name={item.title} value={item.title} checked={item?.isChecked || false} onChange={handleCheckBox} /></span>
          <img src={item.img} class="card-img-top" alt={item.title} height={350} width={300} />
          <div class="card-body">
            <h5 class="card-title">{item.title}</h5>
            <p class="card-text">₹{item.price}</p>

            <div className='d-flex flex-column justify-content-center p-2 text-center'>

              {auth.email && localStorage.getItem('token-info') && <Link to={`/products/${item.id}`} class="btn btn-dark" onClick={handlealert}>Details view</Link>}
              {auth.email1 &&
                <>
                  <button className="btn btn-info mt-2" onClick={() => { dispatch({ type: "ADD", payload: item }); handlecart(); toast.success("added successsfully") }}>Add to cart</button><br />
                </>}

            </div>
          </div>
        </div>
      </>
    )
  }
  return (
    <div>
      <div className='container py-5'>
        <div className='row'>
          <div className='col-7 text-center my-4 ml-5 search'>
            <h1>Products</h1>
            <form class="d-flex">
              <input class="form-control me-2" type="search"
                placeholder="Search" aria-label="Search" value={search}
                onChange={e => { setSearch(e.target.value) }} />
            </form>
            <hr />
            <p>select all:  </p><span><input type='checkbox' name='allselect' onChange={handleCheckBox} checked={!products.some((product) => product?.isChecked !== true)} /></span>
            {auth.email1 &&
              <>
                <button className="btn btn-danger mt-2" onClick={() => { handlecart(); toast.error("Deleted");handledelete() }}>DELETE</button><br />
              </>}
          </div>
        </div>
      </div>
      <div className='container'>
        <div className='row justify-content-around'>
          {products.filter(item => (item.title.toLowerCase()).includes(search.toLowerCase())).map(cardItem)}
        </div>
      </div>
    </div>
  )
}

export default Product
