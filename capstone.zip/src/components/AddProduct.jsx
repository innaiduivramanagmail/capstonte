import React, { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { toast } from 'react-toastify'
//import { useAuth } from './Auth';

function AddProduct() {
  const [id, setId] = useState(null);
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [manufacturer, setManufacturer] = useState("");
  const [price, setPrice] = useState("");
  const [quantity, setQuantity] = useState("");
  const [img, setImg] = useState("")

//  const auth=useAuth()

  const navigate = useNavigate()

  const IsValidate = () => {
    let isproceed = true;
    let errormessage = 'please enter the value in';
    if (id === null || id === '') {
      isproceed = false
      errormessage += 'Username'
    }
    if (!isproceed) {
      toast.error(errormessage)
    }
    return isproceed;
  }

  const submitHandler = (e) => {

    e.preventDefault();

    let ProObj = { id, title, content, manufacturer, price, quantity, img };
  //  console.log(ProObj)
    if (IsValidate) {
      fetch("http://localhost:3000/products", {
        method: "POST",
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify(ProObj)
      }).then((res) => {
        toast.success('Product Added Successfully')
       
        navigate('/')
      }).catch((err) => {
        toast.error('Failed:' + err.message)
      })
    }
   
  }

  return (
    <div>
      <div className='offset-lg-3 col-lg-6'>
        <form className='container' onSubmit={submitHandler}>
          <div className='card'>
            <div className='card-header'>
              <h1>Add a New Product</h1>
            </div>
            <div className='card-body'>

              <div className='row'>
                <div className='col-lg-6'>
                  <div className='form-group'>
                    <label>ID<span className='errmsg'>*</span></label>
                    <input required type="number" className='form-control' value={id} onChange={e => setId(e.target.value)} />
                  </div>
                </div>
                <div className='col-lg-6'>
                  <div className='form-group'>
                    <label>Product Name<span className='errmsg'>*</span></label>
                    <input required type="text" className='form-control' value={title} onChange={e => setTitle(e.target.value)} />
                  </div>
                </div>

                <div className='col-lg-6'>
                  <div className='form-group'>
                    <label>Product Description<span className='errmsg'>*</span></label>
                    <input required type="text" className='form-control' value={content} onChange={e => setContent(e.target.value)} />
                  </div>
                </div>
                <div className='col-lg-6'>
                  <div className='form-group'>
                    <label>Manufacturer<span className='errmsg'>*</span></label>
                    <input required type="text" className='form-control' value={manufacturer} onChange={e => setManufacturer(e.target.value)} />
                  </div>
                </div>
                <div className='col-lg-6'>
                  <div className='form-group'>
                    <label>Price<span className='errmsg'>*</span></label>
                    <input required type="number" className='form-control' value={price} onChange={e => setPrice(e.target.value)} />
                  </div>
                </div>
                <div className='col-lg-6'>
                  <div className='form-group'>
                    <label>Quantity<span className='errmsg'>*</span></label>
                    <input required type="number" className='form-control' value={quantity} onChange={e => setQuantity(e.target.value)} />
                  </div>
                </div>
                <div className='col-lg-12'>
                  <div className='form-group'>
                    <label>Image</label>
                    <input required className='form-control' value={img} onChange={e => setImg(e.target.value)}></input>
                  </div>
                </div>
              </div>

            </div>
            <div className='card-footer'>
              <button type='submit' className='btn btn-primary'>Register</button>
              <Link to="/" type='submit' className='btn btn-danger'>Back</Link>
            </div>
          </div>
        </form>
      </div>
    </div>
  )
}

export default AddProduct
