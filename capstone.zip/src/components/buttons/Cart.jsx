//import React, { useState } from 'react'
import React from 'react'
import { NavLink } from 'react-router-dom'
import { useContext } from 'react'
import { Cartcontext } from '../context/Context'
//import { useSelector } from 'react-redux'


function Cart(item) {
  const Globalstate = useContext(Cartcontext);
  const state = Globalstate.state
  const dispatch = Globalstate.dispatch;

  //we get the state of the additems
  //write the name of the file not the fuction
 // const state=useSelector((state)=>state.addItem)
 
  return (
    <>
      <NavLink to='/cart' className='btn btn-outline-primary ms-2'><span className='fa fa-shopping-cart'></span>Cart ({state.length})</NavLink>
    </>
  )
}

export default Cart
