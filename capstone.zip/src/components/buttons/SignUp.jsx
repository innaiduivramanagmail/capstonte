import React, { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { toast } from 'react-toastify'
import { useAuth } from '../Auth';

function Register() {
  const [id, setId] = useState("");
  const [fName, setfName] = useState("");
  const [lName, setlName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [phone, setPhone] = useState("");
  const [location, setLocation] = useState("")
  const auth = useAuth()
const navigate=useNavigate()
  //const navigate = useNavigate()
  const IsValidate = () => {
    let isproceed = true;
    let errormessage = 'please enter the value in';
    if (id === null || id === '') {
      isproceed = false
      errormessage += 'Username'
    }
    if (!isproceed) {
      toast.error(errormessage)
    }
    return isproceed;
  }
  const submitHandler = (e) => {
    e.preventDefault();
    let RegObj = { id, fName, lName, email, password, phone, location };
    console.log(RegObj)

    if (IsValidate) {

      fetch("http://localhost:3000/users", {

        method: "POST",

        headers: { 'content-type': 'application/json' },

        body: JSON.stringify(RegObj)

      }).then((res) => {

        toast.success('Registered Successfully')
        const userData={id,email,password,phone,location}
        localStorage.setItem('token-info', JSON.stringify(userData));

        auth.register(email)

        navigate('/')

      }).catch((err) => {

        toast.error('Failed:' + err.message)
      })
    }
  }
  return (
    <div>
      <div className='offset-lg-3 col-lg-6'>
        <form className='container' onSubmit={submitHandler}>
          <div className='card'>
            <div className='card-header'>
              <h1>User Registeration</h1>
            </div>
            <div className='card-body'>
              <div className='row'>
                <div className='col-lg-6'>
                  <div className='form-group'>
                    <label>User Name<span className='errmsg'>*</span></label>
                    <input required type="text" className='form-control' value={id} onChange={e => setId(e.target.value)} />
                  </div>
                </div>
                <div className='col-lg-6'>
                  <div className='form-group'>
                    <label>First Name<span className='errmsg'>*</span></label>
                    <input required type="text" className='form-control' value={fName} onChange={e => setfName(e.target.value)} />
                  </div>
                </div>
                <div className='col-lg-6'>
                  <div className='form-group'>
                    <label>Last Name<span className='errmsg'>*</span></label>
                    <input required type="text" className='form-control' value={lName} onChange={e => setlName(e.target.value)} />
                  </div>
                </div>
                <div className='col-lg-6'>
                  <div className='form-group'>
                    <label>Email<span className='errmsg'>*</span></label>
                    <input required type="email" className='form-control' value={email} onChange={e => setEmail(e.target.value)} />
                  </div>
                </div>
                <div className='col-lg-6'>
                  <div className='form-group'>
                    <label>Password<span className='errmsg'>*</span></label>
                    <input required type="password" className='form-control' value={password} onChange={e => setPassword(e.target.value)} />
                  </div>
                </div>
                <div className='col-lg-6'>
                  <div className='form-group'>
                    <label>Phone Number<span className='errmsg'>*</span></label>
                    <input required type="password" className='form-control' value={phone} onChange={e => setPhone(e.target.value)} />
                  </div>
                </div>
                <div className='col-lg-12'>
                  <div className='form-group'>
                    <label>Location</label>

                    <textarea required className='form-control' value={location} onChange={e => setLocation(e.target.value)}></textarea>

                  </div>

                </div>

              </div>




            </div>

            <div className='card-footer'>

              <button type='submit' className='btn btn-primary'>Register</button>

              <Link to="/" type='submit' className='btn btn-danger'>Back</Link>
              <Link to="/login" type='submit' className='btn btn-success'>Login</Link>

            </div>

          </div>

        </form>

      </div>




    </div>

  )

}




export default Register