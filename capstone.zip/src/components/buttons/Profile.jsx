import React, { useEffect, useState } from 'react'
import { Link } from 'react-router-dom';
import { toast } from 'react-toastify'

function Profile() {
  const [data, setData] = useState([])
  useEffect(() => {
    fetch('http://localhost:3000/users')
      .then(response => response.json())
      .then(json => setData(json))
  }, [])
  const [active, setActive] = useState(false)

  const profileData = JSON.stringify(localStorage.getItem('token-info'))
  const remove = () => {
    localStorage.removeItem('token-info')
    setActive(true);
    if (window.confirm("Are you sure want to Remove Profile?")) {
      toast.success("profile removed  Successfully")
    }
    else {
      window.location = '/'
    }
  }
  return (
    <div>

      <h1>{profileData.id}</h1>
      
      {data.map(item =>
        <div className='container ' key={item.id}>
          <div className='row'>
            <div className='profile_card col-lg-6' key={item.id}>
            <h3 className='profile1'>User Name:<span className='profile'>{item.id}</span></h3>
            <h3 className='profile1'>Email:<span className='profile'>{item.email}</span></h3>
            <h3 className='profile1'>Password:<span className='profile'>{item.password}</span></h3>
            <h3 className='profile1'>Contact:<span className='profile'>{item.phone}</span></h3>
            <h3 className='profile1'>Location:<span className='profile'>{item.location}</span></h3>
            </div>
          </div>
          <Link to='/register' className='btn btn-danger' onClick={remove}>Remove</Link>
        </div>
        
       )}
      
    </div>
  )
}

export default Profile









