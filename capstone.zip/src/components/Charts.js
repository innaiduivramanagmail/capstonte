import React, { useState, useEffect } from 'react'
import { Chart as ChartJS, ArcElement, Tooltip, Legend } from 'chart.js'

import { Pie, pie } from 'react-chartjs-2'
ChartJS.register(ArcElement, Tooltip, Legend);


const Charts = () => {

  const[watch,setWatch]=useState([])
  const[glassess,setGlassess]=useState([])
  const [bracelets,setBracelets]=useState([])
  const[pants,setPants]=useState([])
  const[shoe,setShoe]=useState([])
  const[rings,setRings]=useState([])

  useEffect(() => {
    const getWatch=[];
    const getGlassess=[];
    const getBreacelets=[];
    const getPants=[];
    const getShoe=[];
    const getRings=[]
    const getData = async () => {
      const reqData = await fetch("http://localhost:3000/products");
      const resData = await reqData.json()
      console.log(resData)
      for(let i=0;i<resData.length;i++){
        getWatch.push(resData[i].title)
      }
    }
    getData()
  },[])

  return (
    <div>
      <h1 className='text-center mt-3'>Top viewed products</h1>
      <div className='row'>
        <div className='col-md-5 mb-3 mt-3 '></div>
        <div className='col-md-4 mb-3 mt-3 '>
          <Pie
            width={300}
            height={200}
            data={{
              labels: ['watches', 'Coats', 'Yellow', 'Green', 'Purple', 'Orange'],
              datasets: [
                {
                  label: '# of Votes',
                  data: [12, 19, 3, 5, 2, 3],
                  backgroundColor: [
                    'rgba(255, 99, 132, 0.2)',
                    'rgba(54, 162, 235, 0.2)',
                    'rgba(255, 206, 86, 0.2)',
                    'rgba(75, 192, 192, 0.2)',
                    'rgba(153, 102, 255, 0.2)',
                    'rgba(255, 159, 64, 0.2)',
                  ],
                  borderColor: [
                    'rgba(255, 99, 132, 1)',
                    'rgba(54, 162, 235, 1)',
                    'rgba(255, 206, 86, 1)',
                    'rgba(75, 192, 192, 1)',
                    'rgba(153, 102, 255, 1)',
                    'rgba(255, 159, 64, 1)',
                  ],
                  borderWidth: 1,
                },
              ],
            }}
            optios={{
              responsive: true,
              plugins: {
                title: {
                  fontSize: 30,
                  text: 'Products Top view',
                  display: true,
                  font: { size: 20 }
                },
                Legend: {
                  labels: {
                    font: { size: 15 }
                  }
                }
              }
            }}
          />
        </div>
      </div>
    </div>
  )
}

export default Charts
