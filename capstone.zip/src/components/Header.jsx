import React, { useState } from 'react'
import { Link, NavLink } from 'react-router-dom'
//import Home from './Home'
//import Cart from './buttons/Cart'
//import Login from './buttons/Login'
//import SignUp from './buttons/SignUp'
import { useContext } from 'react'
import { Cartcontext } from '../context/Context'
import { useAuth } from './Auth'
import { toast } from 'react-toastify'

function Header({ size }) {

    const auth = useAuth();

    const Globalstate = useContext(Cartcontext);
    const state = Globalstate.state
    const dispatch = Globalstate.dispatch;

    const len = state.reduce((len, item) => {
        return len + item.quantity

    }, 0);


    const [active, setActive] = useState(false)
    const logOut = () => {
        localStorage.removeItem('token-info');
        setActive(true);
        if (window.confirm("Are you sure want to logOut?")) {
            toast.success("LogOut Successfully")
        }
        else {
            window.location = '/'
        }
    }

    return (
        <>
            <nav className="navbar navbar-expand-lg bg-light">
                <div className="container-fluid py-2">

                    <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <span className="navbar-toggler-icon"></span>
                    </button>
                    <div className="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul className="navbar-nav me-auto mb-2 mb-lg-0">
                            <li className="nav-item">
                                <NavLink className="nav-link active" aria-current="page" to="/">Home</NavLink>
                            </li>
                            <li className="nav-item">
                                <NavLink className="nav-link" to="/products">Product</NavLink>
                            </li>
                            <li className="nav-item">
                                <NavLink className="nav-link" to="/about">About</NavLink>
                            </li>
                            <li className="nav-item">
                                <NavLink className="nav-link" to="/contact">Contact</NavLink>
                            </li>
                            <li className="nav-item">
                                <NavLink className="nav-link" to="/chart">Charts</NavLink>
                            </li>
                            <li className="nav-item">
                                {auth.email1 && <NavLink to="/addproduct" className='nav-link'>Add Product</NavLink>}
                            </li>



                        </ul>

                        <Link className="navbar-brand mx-auto fw-bold" to='/'>MEN'S MART</Link>


                        {!auth.email1 && <Link to="/login" className='btn btn-outline-primary my-2'>Login</Link>}
                        {auth.email1 && <Link to="/login" className='btn btn-outline-primary my-2' onClick={logOut}>{active ? "Login" : "LogOut"}</Link>}

                        <Link to="/cart" className='btn btn-outline-primary my-2 fa fa-shopping-cart'>Cart({len})</Link>
                        {auth.email && <Link to="/profile" className='btn btn-outline-primary my-2'>Profile</Link>}
                        {!auth.email && <Link to="/register" className='btn btn-outline-primary my-2'>Register</Link>}
                    </div>

                </div>
            </nav>

        </>
    )
}

export default Header
