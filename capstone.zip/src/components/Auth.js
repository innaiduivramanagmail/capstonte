import {  createContext, useContext, useState } from 'react'

const AuthContext=createContext(null)

export const AuthProvider=({children})=>{
    const[email,setEmail]=useState(null);
    const[email1,setLogin]=useState(null);
    const[product,setProduct]=useState(null);

    const register=(email)=>{
        setEmail(email)
    }
    const login=(email1)=>{
        setLogin(email1)
    }
    const addProduct=(product)=>{
        setProduct(product)
    }
    
return <AuthContext.Provider value={{email,email1,product,register,login,addProduct}}>{children}</AuthContext.Provider>
}
 export const useAuth=()=>{
    return useContext(AuthContext)
 }