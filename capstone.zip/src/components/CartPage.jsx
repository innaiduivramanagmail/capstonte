import React from 'react'
import { useContext } from 'react'
import { Cartcontext } from '../context/Context'
import { Link } from 'react-router-dom';

function CartPage() {
  const Globalstate = useContext(Cartcontext);
  const state = Globalstate.state
  const dispatch = Globalstate.dispatch;
  const total = state.reduce((total, item) => {
    return total + item.price * item.quantity

  }, 0);


  return (
    <div>
      {state.map((item, index) => {
        return (
          <div className='card d-flex container' key={index}>
            <div className='row d-flex py-3 my-3 Cartcard'>
              <div className='col-lg-6 d-flex flex-row py-3 my-3 Cartcard'>
                <img src={item.img} alt='' height={140} width={140} />

                <p><h5>name: </h5>{item.title}</p>
                <p><h5>price:</h5>{item.price}</p>
                <p><h5>Quantity:</h5>{item.quantity}</p>
                <p><h5>Total Price:</h5>{item.quantity * item.price}</p>
                <div className='quantity d-flex flex-column'>
                  <span><button className='btns' onClick={() => dispatch({ type: "INCREASE", payload: item })}>+</button></span>
                  <p className='quantity'>{item.quantity}</p>
                  <span><button className='btns' onClick={() => {
                    if (item.quantity > 1) {
                      dispatch({ type: "DECREASE", payload: item })
                    } else {
                      dispatch({ type: "REMOVE", payload: item })
                    }
                  }}>
                    -</button></span>
                </div>

                <span><button onClick={() => dispatch({ type: "REMOVE", payload: item })} className='btn btn-outline-primary text-end' height="30px" width="50px">Remove</button></span>
              </div>
            </div>
          </div>
        )
      })}

      {state.length > 0 && (<div className='total'><h2>Total cost:{total}</h2></div>)}
      {state.length < 1 && (<div className='emptycart'>
        <h2 className='my-5 py-5'>Your cart is Empty</h2>
        <Link to='/products' className='Gotoproducts btn btn-outline-primary'>Continue shopping</Link>
      </div>)}

    </div>
  )
}

export default CartPage
