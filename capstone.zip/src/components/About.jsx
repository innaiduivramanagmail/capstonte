import React from 'react'
import { Link } from 'react-router-dom'
import Aboutimg from './images/Aboutimg.jpg'

function About() {
  return (
    <div>
      <div className='container py-5 my-5'>
        <div className='row'>
          <div className='col-md-6'>
            <h1 className='text-primary fw-bold mb-4'>About Us</h1>
            <p className='lead mb-4'>
              <ul className='b'>
                <li> Lorem ipsum dolor sit amet consectetur adipisicing elit.
              Voluptate iure recusandae aliquam ab eos corporis animi atque, error ipsa illo impedit sapiente.
              </li>
                <li> Cupiditate hic, itaque qui magnam animi voluptates ducimus saepe,
              architecto amet sunt pariatur vel quae. Rem dolore impedit quasi.
             </li>
                <li>ipsum voluptates laboriosam nesciunt iste dolorem sapiente.
              Lorem ipsum dolor sit amet consectetur adipisicing elit.
              </li>
              <li>ipsum voluptates laboriosam nesciunt iste dolorem sapiente.
              Lorem ipsum dolor sit amet consectetur adipisicing elit.
              </li>
              </ul>
              
             
              
            </p>
            <Link to="/contact" className='btn btn-outline-primary px-3'>Contact Us</Link>
          </div>
          <div className='col-md-6 d-flex justify-content-center'>
            <img src={Aboutimg} alt='About Us' height="400px" width="400px" />
          </div>
        </div>
      </div>
    </div>
  )
}

export default About
